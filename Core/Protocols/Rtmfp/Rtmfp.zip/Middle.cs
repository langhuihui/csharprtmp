﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CSharpRTMP.Common;
using CSharpRTMP.Core.NetIO;
using OpenSSL.Crypto;

namespace CSharpRTMP.Core.Protocols.Rtmfp
{
    public class Middle:Session
    {
        public Peer MiddlePeer;
        private Dictionary<uint, Session> _sessions;
        private Target _target;
        private bool _isPeer;
        private string _queryUrl;
        private int _middleId;
        private bool _firstResponse;
        private byte[] _middleCertificat;
        private DHWrapper _pMiddleDH;
        private static readonly byte[] InitBytes = { 0x02, 0x1D, 0x02, 0x41, 0x0E, 0x03, 0x1A, 0x02, 0x0A, 0x02, 0x1E, 0x02 };
        public Middle(Peer peer, byte[] decryptKey, byte[] encryptKey, Target target)
            : base(peer, decryptKey, encryptKey)
        {
            MiddlePeer = peer;
            _target = target;
            _isPeer = _target.IsPeer;
            _queryUrl = "rtmfp://" + target.Address + peer.Path;
            RtmfpUtils.UnpackUrl(_queryUrl,out MiddlePeer.Path,out MiddlePeer.Properties);
            var udpProtocol = new UDPProtocol {NearProtocol = this};
            var carrier = UDPCarrier.Create("", 0,this);
            carrier.OutboundFd.Connect(target.Address);
            carrier.ReadEnabled = true;
            _middleCertificat = Utils.GenerateRandomBytes(77);
            Buffer.BlockCopy(InitBytes, 0, _middleCertificat,0, 5);
            Buffer.BlockCopy(InitBytes, 5, _middleCertificat,69, 7);
            _writer.Clear(12);
            if (_isPeer)
            {
                _pMiddleDH = target.DH;
                MiddlePeer.Id = (byte[]) target.Id.Clone();
                _writer.Write((byte) 0x22);
                _writer.Write((byte) 0x21);
                _writer.Write((byte) 0x0F);
                _writer.Write(target.PeerId);
            }
            else
            {
                _writer.Write((byte)(_queryUrl.Length+2));
                _writer.Write((byte)(_queryUrl.Length + 1));
                _writer.Write((byte)0x0A);
                _writer.Write(_queryUrl.ToBytes());
            }
            _writer.Write(Utils.GenerateRandomBytes(16));
            SendHandshakeToTarget(0x30);
        }

        private void SendHandshakeToTarget(byte type)
        {
            _writer.BaseStream.Position = 6;
            _writer.Write((byte)0x0b);
            _writer.Write(RtmfpUtils.TimeNow());
            _writer.Write(type);
            _writer.Write((short)(_writer.BaseStream.GetAvaliableByteCounts()-2));
            var encoder = aesEncrypt.Next(AESEngine.AESType.SYMMETRIC);
            RtmfpUtils.Encode(encoder,_writer);
            RtmfpUtils.Pack(_writer,0);
            EnqueueForOutbound();
            _writer.Clear(11);
        }
        public override bool EnqueueForOutbound()
        {
            return FarEndpoint.IOHandler.SignalOutputData();
        }

        public override bool AllowFarProtocol(ulong type)
        {
            return type.TagKindOf(ProtocolTypes.PT_UDP);
        }

        public H2NBinaryWriter Handshaker
        {
            get
            {
                _writer.Clear(12);
                return _writer;
            }
        }
    }
}
