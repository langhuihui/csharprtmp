﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using CSharpRTMP.Common;
using CSharpRTMP.Core.Protocols.Rtmp;
using OpenSSL.Core;


namespace CSharpRTMP.Core.Protocols.Rtmfp
{
    public static class RtmfpUtils
    {
        public const ushort RTMFP_DEFAULT_PORT = 1935;
        public const int ID_SIZE = 0x20;
        public const byte KEY_SIZE = 0x80;
        public const int RTMFP_MAX_PACKET_LENGTH = 1192;
        
        public static ushort TimeNow()
        {
            return (ushort) (DateTime.Now.SecondsFrom1970()/Defines.RTMFP_TIMESTAMP_SCALE);
        }

        public static ushort Time(TimeSpan timeSpan)
        {
            return (ushort)(timeSpan.TotalSeconds/ Defines.RTMFP_TIMESTAMP_SCALE);
        }

        public static DHWrapper BeginDiffieHellman(ref byte[] pubKey, bool initiator = false)
        {
            var dh = new DHWrapper();
            const int size = 128;
            var index = pubKey.Length;
            var newPubKey = new byte[index + 4 + size];
            Buffer.BlockCopy(pubKey,0,newPubKey,0,index);
            var byte2 = (byte) (KEY_SIZE - size);
            if (byte2 > 2)
            {
                Logger.WARN("Generation DH key with less of 126 bytes!");
                byte2 = 2;
            }
            byte2 = (byte) (2 - byte2);
            newPubKey[index++] = 0x81;
            newPubKey[index++] = byte2;
            newPubKey[index++] = (byte) (initiator ? 0x1D : 0x0D);
            newPubKey[index++] = 0x02;
            Buffer.BlockCopy(dh.PublicKey, 0, newPubKey, index, size);
            pubKey = newPubKey;
            return dh;
        }

        public static void UnpackUrl(string url,out string path,
            out NameValueCollection properties)
        {
            string host;
            ushort port;
            UnpackUrl(url,out host,out port,out path,out properties);
        }
        public static void UnpackUrl(string url, out string host, out ushort port, out string path,
            out NameValueCollection properties)
        {
            var uri = new Uri(url);
            //uri.normalize
            path = uri.AbsolutePath;
            host = uri.Host;
            port =(ushort) uri.Port;
            properties = HttpUtility.ParseQueryString(uri.Query);
        }

        
        public static bool Decode(AESEngine aesDecrypt,N2HBinaryReader packet)
        {
            //var pos = packet.BaseStream.Position;
            //var buffer = packet.ReadBytes((int) packet.BaseStream.GetAvaliableByteCounts());
	// Decrypt
           // packet.BaseStream.Position = pos;
            aesDecrypt.Process(packet.BaseStream as MemoryStream);
            //packet.BaseStream.Write(buffer,0,buffer.Length);
	        return ReadCRC(packet);
        }
        public static bool ReadCRC(N2HBinaryReader packet)
        {
	        // Check the first 2 CRC bytes 
	        packet.BaseStream.Position = 4;
            UInt16 sum = packet.ReadUInt16();
	        return (sum == CheckSum(packet.BaseStream));
        }
        public static void Encode(AESEngine aesEncrypt, H2NBinaryWriter writer)
        {
            if (aesEncrypt.Type != AESEngine.AESType.EMPTY)
            {
                var paddingBytesLength = (0xFFFFFFFF - (int)writer.BaseStream.Length+ 5) & 0x0F;
                writer.BaseStream.Position = writer.BaseStream.Length;
                for (var i = 0; i < paddingBytesLength; i++)
                {
                    writer.Write((byte)0xFF);
                }
                //writer.Write(Enumerable.Repeat((byte)0xFF, (int) paddingBytesLength).ToArray());
            }
            WriteCRC(writer);
            writer.BaseStream.Position = 4;
            aesEncrypt.Process(writer.BaseStream as MemoryStream);
        }

        public static void WriteCRC(H2NBinaryWriter writer)
        {
            var s = writer.BaseStream;
            s.Position = 6;
            var sum = CheckSum(s);
            s.Position = 4;
            writer.Write(sum);
        }

        public static ushort CheckSum(Stream s)
        {
            int sum = 0;
            var position = (int)s.Position;
            var first = s.ReadByte();
            while (first != -1)
            {
                var second = s.ReadByte();
                if (second != -1)
                {
                    sum += (first << 8) +second;
                    first = s.ReadByte();
                }
                else
                {
                    sum += first;
                    first = -1;
                }
            }
            s.Position = position;
            sum = (sum >> 16) + (sum & 0xFFFF);
            sum += (sum >> 16);
            return (ushort) ~sum;
        }

        public static void Pack(H2NBinaryWriter writer, uint farId)
        {
            var reader = new N2HBinaryReader(writer.BaseStream);
            writer.BaseStream.Position = 4;
            var result = reader.ReadUInt32() ^ reader.ReadUInt32() ^ farId;
            writer.BaseStream.Position = 0;
            writer.Write(result);
        }

        public static void ComputeAsymetricKeys(byte[] sharedSecret, byte[] initiatorNonce, byte[] responderNonce, out byte[] requestKey,out byte[] responseKey)
        {
            uint mdlen = 0;
            var md1 = new byte[AESEngine.AES_KEY_SIZE];
            var md2 = new byte[AESEngine.AES_KEY_SIZE];
            //var hmac = new HMACSHA256(responderNonce);
            //var md1 = hmac.ComputeHash(initiatorNonce, 0, initiatorNonce.Length);
            //hmac = new HMACSHA256(initiatorNonce);
            //var md2 = hmac.ComputeHash(responderNonce, 0, responderNonce.Length);
            //hmac = new HMACSHA256(md1);
            //requestKey = hmac.ComputeHash(sharedSecret, 0, sharedSecret.Length);
            //hmac = new HMACSHA256(md2);
            //responseKey = hmac.ComputeHash(sharedSecret, 0, sharedSecret.Length);

            Native.HMAC(Native.EVP_sha256(), responderNonce, responderNonce.Length, initiatorNonce,
                initiatorNonce.Length, md1, ref mdlen);
            Native.HMAC(Native.EVP_sha256(), initiatorNonce, initiatorNonce.Length, responderNonce,
                responderNonce.Length, md2, ref mdlen);
            requestKey = new byte[AESEngine.AES_KEY_SIZE];
            responseKey = new byte[AESEngine.AES_KEY_SIZE];
            Native.HMAC(Native.EVP_sha256(), sharedSecret, sharedSecret.Length, md1,
              AESEngine.AES_KEY_SIZE, requestKey, ref mdlen);
            Native.HMAC(Native.EVP_sha256(), sharedSecret, sharedSecret.Length, md2,
               AESEngine.AES_KEY_SIZE, responseKey, ref mdlen);
        }
    }
}
